package com.chargingstation;

public class ChargeStationfullException extends Exception{

	ChargeStationfullException()
	{
		super();
	}
	ChargeStationfullException(String s)
	{
		super(s);
	}
}
